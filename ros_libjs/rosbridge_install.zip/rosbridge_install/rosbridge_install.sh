#!/bin/bash
echo "123456" | sudo -S dpkg -i python3-tornado*
echo "123456" | sudo -S dpkg -i python3-bson*
echo "123456" | sudo -S dpkg -i ros-noetic-rosbridge-library*
echo "123456" | sudo -S dpkg -i ros-noetic-rosapi*
echo "123456" | sudo -S dpkg -i ros-noetic-rosauth*
echo "123456" | sudo -S dpkg -i ros-noetic-rosbridge-msgs*
echo "123456" | sudo -S dpkg -i ros-noetic-rosbridge-server*
