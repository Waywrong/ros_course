#!/bin/bash
dpkg -i apache2-utils*
dpkg -i apache2-data*
dpkg -i libaprutil1-dbd-sqlite3*
dpkg -i libaprutil1-dbd-mysql*
dpkg -i libaprutil1-dbd-odbc*
dpkg -i libaprutil1-dbd-pgsql*
dpkg -i libaprutil1-ldap*
dpkg -i liblua5.2-0*
dpkg -i apache2-bin*
dpkg -i apache2_2.4.41-4ubuntu3.14_amd64.deb
